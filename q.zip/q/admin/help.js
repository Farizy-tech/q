exports.allmenu = (prefix, namaowner) => {
	return `[ *BOT* (🥶) ]

~> [ *GROUP* (📌)]
> *${prefix}antilink*
> *${prefix}editinfo*
> *${prefix}group*
> *${prefix}promote*
> *${prefix}demote*
> *${prefix}add*
> *${prefix}kick*
> *${prefix}resetlink*
> *${prefix}linkgroup*
> *${prefix}setdesc*
> *${prefix}setname*

~> [ *CEK* (👑)]
> *${prefix}mykarakter*
> *${prefix}myuang*
> *${prefix}mymedali*
> *${prefix}myexp*
> *${prefix}myenergi*
> *${prefix}claim*

~> [ *CREATIF(1)* (🎨)]
> *${prefix}anjing1*
> *${prefix}anjing2*
> *${prefix}anjing3*
> *${prefix}meme1*
> *${prefix}meme2*
> *${prefix}tampar*
> *${prefix}cerdas*
> *${prefix}tokdalang*
> *${prefix}tom*
> *${prefix}ampun*
• *Note* : Input(Text)

~> [ *CREATIF(2)* (🎨)]
> *${prefix}curiga*
> *${prefix}anda*
> *${prefix}anjing4*
> *${prefix}heran*
> *${prefix}macan*
> *${prefix}mobil*
Note : Input(Text1 & text2)

~> [ *BOT-CHAT* (💌)]
> *${prefix}robot* <chat>

~> [ *RANDOM* (💫)]
> *${prefix}brainly* <soal>

~> [ *AUDIO* (🎶)]
> Pilih audio 1-20
> *Contoh* : ${prefix}audio7

Made By *@adiwajshing/baileys*
Made by *@ProgramInPath/Farizy*`
}
